package com.cg.pagebean;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class ProductPage2 {
	@FindBy(how=How.NAME,name="name")
	private WebElement name;
	@FindBy(how=How.NAME,name="age")
	private WebElement age;
	@FindBy(how=How.NAME,name="degree")
	private List<WebElement> degree;
	@FindBy(how=How.NAME,name="loc")
	private WebElement loc;
	@FindBy(how=How.LINK_TEXT,name="linked")
	private WebElement linked;
	
	public String currentPageTitle(WebDriver driver)
	{
		return driver.getTitle();
		
	}
	
	public void clickLink()
	{
		this.linked.click();
	}
	
	public void setName(String name)
	{
		this.name.clear();
		this.name.sendKeys(name);
	}
	public void setAge(String age)
	{
		this.age.clear();
		this.age.sendKeys(age);
	}
	public void setDegree(String degree)
	{
		for(WebElement elements:this.degree)
		{
			if(elements.isSelected()==true)
				elements.click();
		}
		if(degree.equals("btech"))
			this.degree.get(0).click();
		else
			this.degree.get(1).click();
	}
	public void setLoc(String code)
	{
		//driver.findElement(quantity).clear();
		System.out.println("yyyyyyyyyyyyyyyyyyyyyyyyyy"+code);
		Select dropdown = new Select(this.loc);
		dropdown.deselectAll();
		System.out.println(code);
		if(!code.equals(""))
		{
		Select selectType=new Select(this.loc);
		selectType.selectByVisibleText(code);
		}
	}
	public String getName()
	{
		return this.name.getAttribute("value");
		
	}
	public String getAge()
	{
		return this.age.getAttribute("value");
		
	}
	public String getDegree()
	{
		for(WebElement element: degree)
		{
			if(element.isSelected())
				return element.getAttribute("value");
		}
		return null;
		
	}
}
