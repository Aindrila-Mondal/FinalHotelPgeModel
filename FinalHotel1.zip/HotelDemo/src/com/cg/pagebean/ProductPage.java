package com.cg.pagebean;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class ProductPage {
	//private WebDriver driver;
	//private Alert alert;
	//private JavascriptExecutor scriptExecutor;
	
	/*private By procode = By.name("procode");

   private  By proname = By.name("proname");
    
   private By quantity = By.name("quantity");
    
   private By radio = By.name("radio");
   
   private By submit = By.name("submit"); */
	
	@FindBy(how=How.NAME,name="procode")
	private WebElement procode;
	
	@FindBy(how=How.NAME,name="proname")
	private WebElement proname;
	
	@FindBy(how=How.NAME,name="quantity")
	private WebElement quantity;
	
	@FindBy(how=How.NAME,name="radio")
	private List<WebElement> radio;
	
	@FindBy(name="submit")
	private WebElement submitBtn;
	
   
/*	public ProductPage(WebDriver driver){

        this.driver = driver;

    } */
	
	public void setProCode(String code)
	{
		//driver.findElement(procode).clear();
		System.out.println(code);
		this.procode.sendKeys(code);
	}
	public void setProName(String code)
	{
		//driver.findElement(proname).clear();
		System.out.println(code);
		this.proname.sendKeys(code);
	}
	public void setQuantity(String code)
	{
		//driver.findElement(quantity).clear();
		System.out.println(code);
		if(!code.equals(""))
		{
		Select selectType=new Select(this.quantity);
		selectType.selectByVisibleText(code);
		}
	}
	public void setRadio(String code)
	{
		//driver.findElement(radio).clear();
		if(code.equals("Electronics"))
			this.radio.get(0).click();
		else
			this.radio.get(1).click();
	}
	
	public String getProCode()
	{
		return this.procode.getAttribute("value");
	}
	public String getProName()
	{
		return this.proname.getAttribute("value");
	}
	public String getQuantity()
	{
		return new Select(this.quantity).getFirstSelectedOption().getText();
	}
	public String getRadio()
	{
		for(WebElement element: radio)
		{
			if(element.isSelected())
				return element.getAttribute("value");
		}
		return null;//this.radio.getAttribute("value");
	}
	
	public void clickSubmit(){

		submitBtn.submit();

	    }
	public String currentPageTitle(WebDriver driver)
	{
		return driver.getTitle();
		
	}
	
}
