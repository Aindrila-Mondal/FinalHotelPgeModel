package com.cg.stepdefination;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.cg.pagebean.ProductPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps {
	
	WebDriver driver=null;
	ProductPage obj=null;
	@When("^Internet is working$")
	public void internet_is_working()  {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^User is logged in$")
	public void user_is_logged_in()  {
	    // Write code here that turns the phrase above into concrete actions

		System.setProperty("webdriver.chrome.driver","MyDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\Users\\AKBOSE\\Desktop\\Selinium_HTML_pages\\ProductForm.html");
		
		obj=PageFactory.initElements(driver,ProductPage.class);
		
		//obj=new ProductPage(driver);
		System.out.println("###########################User logged");
	}

	@When("^user is trying to submit data without entering product code$")
	public void user_is_trying_to_submit_data_without_entering_product_code()  {
	    // Write code here that turns the phrase above into concrete actions
	    
			System.out.println("###########################Enter data");
	    	obj.clickSubmit();
	    	System.out.println("###########################enter data end");
	}
	@Then("^'ProductCode should not be empty' alert message should display$")
	public void productcode_should_not_be_empty_alert_message_should_display() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
	   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"ProductCode should not be empty");
	   
	}

	

	@When("^user is trying to submit data without entering product name$")
	public void user_is_trying_to_submit_data_without_entering_product_name() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without name");
		Thread.sleep(500);
		driver.switchTo().alert().dismiss();
		
		 obj.setProCode("123");
		 Thread.sleep(500);
		 obj.clickSubmit();
		 System.out.println("###########################enter data end");
	}


	@Then("^'ProductName should not be empty' alert message should display$")
	public void productname_should_not_be_empty_alert_message_should_display() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
	  
	    Thread.sleep(500);
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"ProductName should not be empty");
	   
	}



	@When("^user is trying to submit data without entering ProductQuantity$")
	public void user_is_trying_to_submit_data_without_entering_ProductQuantity() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println("###########################Enter without quantity");
		
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
	     obj.setProName("Mobile");
	     Thread.sleep(500);
	     obj.clickSubmit();
	     System.out.println("###########################enter data end");
	    
	}
	@Then("^'ProductQuantity should not be empty' alert message should display$")
	public void productquantity_should_not_be_empty_alert_message_should_display() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
	   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"ProductQuantity should not be empty");
	  
	}

	@When("^user is trying to submit data without entering ProductType$")
	public void user_is_trying_to_submit_data_without_entering_ProductType() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without type");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
	     obj.setQuantity("2");
	     Thread.sleep(500);
	     obj.clickSubmit();
	     System.out.println("###########################end");
	}
	
	@Then("^'ProductType should not be empty' alert message should display$")
	public void producttype_should_not_be_empty_alert_message_should_display() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
	  System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"ProductType should not be empty");
	    
	}


@When("^user provides the data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_provides_the_data(String arg1, String arg2, String arg3, String arg4) throws InterruptedException {
    // Write code here that turns the phrase above into concrete actions
	//driver.switchTo().alert().dismiss();
	Thread.sleep(500);
	 obj.setProCode(arg1);
	
     obj.setProName(arg2);
 
     obj.setQuantity(arg3);
  
     obj.setRadio(arg4);
     System.out.println(obj.getProCode());
     System.out.println(obj.getProName());
     System.out.println(obj.getQuantity());
     System.out.println(obj.getRadio());
}

	@When("^User click on Submit button$")
	public void user_click_on_Submit_button() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################4");
		Thread.sleep(500);
		 obj.clickSubmit();
		 Thread.sleep(500);
		
		  Alert alert = driver.switchTo().alert();
		  
		 Assert.assertEquals( alert.getText(),"All correct");
		 alert.accept();
		 System.out.println("###########################5");
	}

	@Then("^Go to success page$")
	public void go_to_success_page()  {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println(obj.currentPageTitle(driver));
	     Assert.assertEquals(obj.currentPageTitle(driver),"success page");
	}

}
