package com.cg.stepdefination;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.cg.pagebean.ProductPage;
import com.cg.pagebean.ProductPage2;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps2 {
	WebDriver driver=null;
	ProductPage2 obj=null;
	@Given("^Authentic User is logged in$")
	public void authentic_User_is_logged_in()   {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","MyDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\Users\\AKBOSE\\Desktop\\Selinium_HTML_pages\\success.html");
		
		obj=PageFactory.initElements(driver,ProductPage2.class);
	}

	@When("^user click on click without entering valid name$")
	public void user_click_on_click_without_entering_valid_name()   {
	  obj.clickLink();
	}

	@Then("^'please enter valid name' alert is displayed$")
	public void please_enter_valid_name_alert_is_displayed() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"please enter valid name");
	}

	@When("^user click on click without entering age$")
	public void user_click_on_click_without_entering_age() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without name");
		Thread.sleep(500);
		driver.switchTo().alert().dismiss();
		
		 obj.setName("Akash");
		 Thread.sleep(500);
		 obj.clickLink();
		 System.out.println("###########################enter data end");
	}

	@Then("^'age cannot be empty' alert is displayed$")
	public void age_cannot_be_empty_alert_is_displayed() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"age cannot be empty");
	}

	@When("^user click on click without entering degree$")
	public void user_click_on_click_without_entering_degree() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without name");
		Thread.sleep(500);
		driver.switchTo().alert().dismiss();
		
		 obj.setAge("12");
		 Thread.sleep(500);
		 obj.clickLink();
		 System.out.println("###########################enter data end");
	}

	@Then("^'degree cannot be empty' alert is displayed$")
	public void degree_cannot_be_empty_alert_is_displayed() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"degree cannot be empty");
	}
	@When("^user click on click without entering location$")
	public void user_click_on_click_without_entering_location() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without name");
		Thread.sleep(500);
		driver.switchTo().alert().dismiss();
		
		 obj.setDegree("mba");
		 Thread.sleep(500);
		 obj.clickLink();
		 System.out.println("###########################enter data end");
	}

	@Then("^'ProductLoc should not be empty' alert is displayed$")
	public void productloc_should_not_be_empty_alert_is_displayed() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"ProductLoc should not be empty");
	   
	}
	
	@When("^user click on click without giving correct valid name$")
	public void user_click_on_click_without_giving_correct_valid_name() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without name");
		Thread.sleep(500);
		driver.switchTo().alert().dismiss();
		obj.setDegree("btech");
		 obj.setName("aka");
		 obj.setLoc("Kolkata");
		 Thread.sleep(500);
		 obj.clickLink();
		 System.out.println("###########################enter data end");
	}

	@Then("^'please enter valid name' alert should be displayed$")
	public void please_enter_valid_name_alert_should_be_displayed() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		   
		System.out.println("###########################After sleep");
	    Alert alert = driver.switchTo().alert();
	    System.out.println("########gettxtx"+alert.getText());
	 
	    Assert.assertEquals( alert.getText(),"please enter valid name");
	
	}
	@When("^user provide all valid data$")
	public void user_provide_all_valid_data() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("###########################Enter without name");
		Thread.sleep(500);
		 driver.switchTo().alert().dismiss();
		 obj.setName("Aindrila");
		 obj.setAge("12");
		 obj.setDegree("mba");
		 obj.setLoc("Mumbai");
		 Thread.sleep(500);
		 obj.clickLink();
		 System.out.println("###########################enter data end");
	}

	@Then("^user goes to welcome page$")
	public void user_goes_to_welcome_page()   {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println(obj.currentPageTitle(driver));
	     Assert.assertEquals(obj.currentPageTitle(driver),"welcome page");
	}

}
